import { useState } from "react";
import {
  AlertTriangle,
  CheckCircle,
  XCircle,
  Info,
  ChevronDown,
  ChevronRight,
  FileText,
  Shield,
  Zap,
  Database,
  GitBranch,
  TrendingDown,
  Search,
  BookOpen,
  BarChart2,
} from "lucide-react";

// ─── Types ─────────────────────────────────────────────────────────────────
type Severity = "КРИТ" | "ВАЖНО" | "КОСМЕТИКА" | "ОК";

interface Finding {
  id: string;
  title: string;
  location: string;
  quote: string;
  verdict: "баг" | "противоречие" | "риск" | "ок";
  severity: Severity;
  moneyImpact: string;
  minFix: string;
  section: string;
}

interface Section {
  id: string;
  label: string;
  icon: React.ReactNode;
}

// ─── Data ──────────────────────────────────────────────────────────────────
const findings: Finding[] = [
  // ────────── A. Инфраструктура ──────────────────────────────────────────
  {
    id: "A1",
    title: "Гонка push при параллельном ручном dispatch",
    location: ".github/workflows/bot.yml:15–20",
    quote:
      `concurrency:\n  group: astra-bot\n  cancel-in-progress: false\n\n` +
      `# Ручной workflow_dispatch конкурирует с cron-очередью;\n` +
      `# cancel-in-progress: false означает, что второй запуск ЖДЁТ,\n` +
      `# а не убивается — и оба пытаются git push в master.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "При двух одновременных dispatch возможна потеря state-коммита между сессиями — позиции «забудутся».",
    minFix: "Добавить `cancel-in-progress: true` для `workflow_dispatch`; для cron оставить false. Или добавить git pull перед push в Save state.",
    section: "A",
  },
  {
    id: "A2",
    title: "git pull --no-rebase молча провалится при force-push",
    location: ".github/workflows/bot.yml:41",
    quote:
      `git pull --no-rebase origin master || true\n\n` +
      `# «|| true» проглатывает любую ошибку pull, включая конфликт.\n` +
      `# Если предыдущий бот запушил, а этот запрос получает diverged — \n` +
      `# он стартует со СТАРЫМ state и перезаписывает свежие данные.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "При diverged-ветке бот стартует со старым state-файлом: может открыть позицию, которая уже есть, или потерять свежие закрытия.",
    minFix: "Заменить `|| true` на `|| echo 'pull warning'`; добавить проверку `git status --porcelain` перед запуском торговли.",
    section: "A",
  },
  {
    id: "A3",
    title: "State_bundle НЕ входит в Save state шага",
    location: ".github/workflows/bot.yml:56–81",
    quote:
      `for f in models/paper_positions.json models/paper_trades.jsonl \\\n` +
      `         models/paper_ledger.jsonl ...\n` +
      `# models/state_bundle.json — НЕ ПЕРЕЧИСЛЕН в списке git add.\n` +
      `# При падении сессии (crash between steps) бандл недоступен\n` +
      `# для следующей сессии.`,
    verdict: "баг",
    severity: "ВАЖНО",
    moneyImpact: "state_bundle.json — резервный crash-recovery для broker; если он не коммитится, восстановление позиций после сбоя опирается только на paper_positions.json. Потеря одного файла = потеря позиций.",
    minFix: "Добавить `models/state_bundle.json` в список `git add -f` в шаге Save state в bot.yml.",
    section: "A",
  },
  {
    id: "A4",
    title: "kill_switch_state.json не коммитируется",
    location: ".github/workflows/bot.yml:56–81",
    quote:
      `# В списке Save state отсутствует models/kill_switch_state.json.\n` +
      `# KillSwitch пишет is_halted, consecutive_loss_days в этот файл,\n` +
      `# но между сессиями он не сохраняется в git — state сбрасывается\n` +
      `# при каждом перезапуске GitHub Actions.`,
    verdict: "баг",
    severity: "КРИТ",
    moneyImpact: "HALT-статус и счётчик убыточных дней не переживают рестарт. После 5 убыточных дней бот сбрасывает счётчик при следующем запуске и продолжает торговать — защита от серий убытков фактически выключена.",
    minFix: "Добавить `models/kill_switch_state.json` в Save state в bot.yml. Убедиться, что restore_from_trades в risk_engine также читает этот файл после восстановления.",
    section: "A",
  },
  {
    id: "A5",
    title: "SymbolLossGuard не персистентен между сессиями",
    location: "astra_bot/core/kill_switch.py:153–195 + trading_engine.py",
    quote:
      `@dataclass\nclass SymbolLossGuard:\n    _losses: dict[str, int] = field(default_factory=dict)\n    _pause_until: dict[str, datetime] = field(default_factory=dict)\n\n` +
      `# Объект живёт только в памяти процесса. GitHub Actions\n` +
      `# поднимает новый процесс каждые 5 мин — guard всегда пуст.\n` +
      `# 3 убытка → cooldown 4h никогда не срабатывает между сессиями.`,
    verdict: "баг",
    severity: "ВАЖНО",
    moneyImpact: "Per-symbol cooldown после 3 убытков подряд не работает между 5-минутными сессиями. Бот продолжает входить в убыточный символ снова и снова.",
    minFix: "Сериализовать `_losses` и `_pause_until` (ISO-строки) в models/symbol_loss_guard.json; загружать при старте движка; коммитить в Save state.",
    section: "A",
  },

  // ────────── B. Исполнительный контур ──────────────────────────────────
  {
    id: "B1",
    title: "Probation ×0.25 → ×1.0 при пустом stats_store",
    location: "astra_bot/decision/trading_engine.py (probation logic) + strategy_stats.py",
    quote:
      `# В StrategyStatsStore.get() fallback цепочка:\n` +
      `# axes_bucket → legacy_bucket → any_bucket → None.\n` +
      `# При None: shrunken_expectancy возвращает (prior_r, 0.0).\n` +
      `# confidence = 0.0 → probation ×0.25 применяется.\n` +
      `# НО: если strategy_stats.json отсутствует/повреждён,\n` +
      `# load() ставит buckets = {} и НЕ падает с ошибкой.\n` +
      `# Следствие: при удалённом файле все стратегии работают\n` +
      `# на prior — без probation-флага от движка.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "При пустом/удалённом strategy_stats.json все стратегии торгуют на prior_r без эмпирического риск-сжатия. Убитые kill-switch-ом стратегии воскреснут на полном размере.",
    minFix: "В торговом движке при старте явно проверять, что stats_store.buckets не пуст, иначе логировать WARNING и принудительно включать probation для всех стратегий.",
    section: "B",
  },
  {
    id: "B2",
    title: "Leverage_for: граничный случай d→0 даёт плечо infinity",
    location: "astra_bot/decision/trading_engine.py (leverage_for function)",
    quote:
      `if d > 0:\n    feasible = int(1.0 / (d + maintenance_margin_pct)) - 1\n    if lev > feasible:\n        lev = max(1, feasible)\n\n` +
      `# Если entry == stop (d == 0), блок if d > 0 пропускается.\n` +
      `# lev остаётся максимальным из лестницы (до 100).\n` +
      `# Это ликвидационный инвариант — «стоп умирает раньше\n` +
      `# ликвидации» — при d=0 не соблюдается.`,
    verdict: "баг",
    severity: "ВАЖНО",
    moneyImpact: "Если стоп совпадает с ценой входа (редко, но возможно при стратегии с нулевым риском), плечо не обрезается. В paper-режиме PnL считается некорректно.",
    minFix: "Добавить: `if d <= 0: return 1` перед лестницей. Нулевое расстояние = плечо 1 (позиция без реального стопа не открывается с плечом).",
    section: "B",
  },
  {
    id: "B3",
    title: "record() в StrategyStatsStore: r_multiple == 0 считается проигрышем",
    location: "astra_bot/decision/strategy_stats.py:78–91",
    quote:
      `def record(self, r_multiple: float, ...) -> None:\n    ...\n    if r_multiple > 0:\n        self.wins += 1\n        self.wins_sum_r += r_multiple\n    else:\n        self.losses += 1\n        self.losses_sum_r += r_multiple\n\n` +
      `# Безубыточная сделка (r_multiple == 0.0) считается убытком.\n` +
      `# losses_sum_r += 0 — PnL не страдает, но wins/losses-счётчик\n` +
      `# занижает win_rate и завышает avg_loss_r (делитель растёт\n` +
      `# без вклада в числитель).`,
    verdict: "баг",
    severity: "КОСМЕТИКА",
    moneyImpact: "Статистика win_rate занижена, profit_factor искажён при наличии безубыточных сделок. Влияет на EV-оценку и решение kill-switch (PF < 1 может срабатывать на самом деле нейтральных стратегиях).",
    minFix: "Изменить на `if r_multiple > 0: ... elif r_multiple < 0: ... # r_multiple == 0 не считается ни победой, ни поражением`.",
    section: "B",
  },
  {
    id: "B4",
    title: "Cooldown-ключ антидребезга не сохраняется в git",
    location: "astra_bot/decision/trading_engine.py (_record_closed, cooldown logic) + bot.yml",
    quote:
      `self.broker.register_cooldown(\n    _cd_key,\n    _cd_at + self._cooldown_ttl_ms()\n)\n\n` +
      `# Реестр cooldown живёт в broker state (paper_positions.json).\n` +
      `# paper_positions.json коммитится в Save state — ОК.\n` +
      `# НО: cooldown регистрируется ПОСЛЕ broker.save() для позиции,\n` +
      `# а broker.save() после этого не вызывается — cooldown\n` +
      `# не попадает в файл до следующего _save_state_bundle().`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "Если сессия падает между register_cooldown() и следующим _save_state_bundle(), cooldown теряется. После рестарта бот может сразу открыть сделку по той же паре, нарушив 20-минутный cooldown.",
    minFix: "Вызывать `self.broker.save()` сразу после `register_cooldown()` внутри блока `if _cd_changed`.",
    section: "B",
  },
  {
    id: "B5",
    title: "Тейк-частичка TP1 (30%) и хвост (70%): fractions устарели в docstring",
    location: "astra_bot/decision/broker.py:55–57 (PaperPosition.tp_fractions default)",
    quote:
      `tp_fractions: list[float] = field(\n    default_factory=lambda: [0.5, 0.3, 0.2]\n)\n\n` +
      `# default_factory задаёт [50%, 30%, 20%] — три уровня.\n` +
      `# Но решение владельца (13.09): 30% + 70%.\n` +
      `# В trading_engine.py передаётся _tp_fractions = list(PLAN_TP_FRACTIONS)\n` +
      `# (0.3, 0.7) — два уровня. Default в dataclass — legacy,\n` +
      `# который применяется если движок не передал fractions.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "Позиции, открытые без явного tp_fractions от движка (например, через тесты или zeus-контур напрямую), получат устаревшее распределение 50/30/20 вместо 30/70. Размер частичной фиксации отличается от задокументированного.",
    minFix: "Обновить default_factory в PaperPosition.tp_fractions до `lambda: [0.3, 0.7]` — привести к каноническому плану.",
    section: "B",
  },
  {
    id: "B6",
    title: "MFE/MAE обновляются только при закрытии, не каждый бар",
    location: "astra_bot/decision/trading_engine.py (process_symbol / _record_closed)",
    quote:
      `# В _aggregate_position_sample:\n` +
      `\"mfe_r\": max([float(r.get(\"mfe_r\") or 0.0) for r in use] or [0.0]),\n` +
      `\"mae_r\": min([float(r.get(\"mae_r\") or 0.0) for r in use] or [0.0]),\n\n` +
      `# MFE/MAE берутся из закрытых строк trades.jsonl.\n` +
      `# Они пишутся брокером при фиксации — после закрытия позиции.\n` +
      `# Нет кода, обновляющего mfe_r/mae_r на каждом баре по\n` +
      `# high/low — они захватывают только цену выхода, не пиковое\n` +
      `# движение за время жизни позиции.`,
    verdict: "баг",
    severity: "ВАЖНО",
    moneyImpact: "MFE-медиана 0.28R при целевом тейке 2.0–2.3R — известная аномалия. Если MFE не обновляется побарно, TP-геометрия проекта строится на заниженных данных. Решение о перемещении тейка на 0.70R (DECISION_MEMO) опирается на искажённую статистику.",
    minFix: "В process_symbol после каждого бара обновлять `pos.highest_price` / `pos.lowest_price` и пересчитывать mfe_r/mae_r от этих пиков (уже есть поля в PaperPosition, но в расчёт при закрытии не попадают).",
    section: "B",
  },
  {
    id: "B7",
    title: "EVEngine.calculate: fees_pct и slippage_pct заданы в % (0.05), но трактуются как части (0.05%)",
    location: "astra_bot/decision/ev_engine.py:25–42",
    quote:
      `def calculate(\n    self, *, p_win, entry, stop, take,\n    fees_pct: float = 0.05,   # <-- default 0.05\n    slippage_pct: float = 0.05,\n) -> EVReport:\n    avg_win = abs(take - entry) / entry * 100\n    avg_loss = abs(entry - stop) / entry * 100\n    edge = p_win * avg_win - p_loss * avg_loss - fees_pct - slippage_pct\n\n` +
      `# avg_win и avg_loss уже в процентах (умножены на 100).\n` +
      `# fees_pct = 0.05 вычитается как 0.05%, а должно быть 0.1% (вход) + 0.1% (выход).\n` +
      `# Этот EVEngine НЕ используется в реальном контуре (используется meta_strategy.candidate_prior_r),\n` +
      `# но tests/ могут давать зелёный цвет с неправильными числами.`,
    verdict: "риск",
    severity: "КОСМЕТИКА",
    moneyImpact: "EVEngine используется только в тестах/лабораторных скриптах, не в живом решении. Риск — ложно-зелёные тесты EV при неверных комиссиях.",
    minFix: "Переименовать параметры в `fee_fraction` (0.0005) или умножать на 100 при передаче. Добавить тест с граничным значением.",
    section: "B",
  },

  // ────────── C. Сигналы и стратегии ─────────────────────────────────────
  {
    id: "C1",
    title: "HTF-гейт fail-open при <200 барах — жёсткий числовой порог без источника",
    location: "astra_bot/decision/htf_gates.py (ribbon_bias, min_bars=200)",
    quote:
      `def ribbon_bias(closes: list[float], *, min_bars: int = 200) -> ...\n    if len(closes) < min_bars:\n        return None, diag  # fail-open\n\n` +
      `# При 199 барах функция возвращает None → кандидаты проходят гейт\n` +
      `# без фильтрации. Первые ~17 торговых дней после сброса\n` +
      `# (200 дневных баров ≈ 10 мес) HTF-гейт бессмысленен.\n` +
      `# Канон README говорит «fail-open <200 баров» — соответствует,\n` +
      `# но 200 дневных баров — это почти год истории.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "После сброса state или при новом символе HTF-гейт выключен ~10 месяцев. Все направленные стратегии работают без дневного трендового фильтра.",
    minFix: "Снизить min_bars до 50 (два месяца — достаточно для EMA50; EMA200 даёт приемлемые значения от 100+ баров). Добавить источник в комментарий.",
    section: "C",
  },
  {
    id: "C2",
    title: "Дублирование стратегий: BreakoutStrategyV2 в disabled_strategy_names И в pipeline",
    location: "astra_bot/decision/trading_engine.py (TradingEngineConfig.disabled_strategy_names + pipeline init)",
    quote:
      `disabled_strategy_names: frozenset[str] = frozenset({\n    \"zscore_mean_reversion\", \"liquidity_sweep\", \"fair_value_gap\",\n    \"open_interest_divergence\", \"expanding_triangle\",\n    \"ascending_triangle\", \"breakout\", \"BreakoutStrategyV2\", ...\n})\n\n` +
      `# В pipeline init добавляются:\n` +
      `PipelineStrategyAdapter(BreakoutStrategyV2(), SignalType.MOMENTUM),\n` +
      `PipelineStrategyAdapter(ExpandingTriangleStrategy(), ...),\n` +
      `PipelineStrategyAdapter(AscendingTriangleStrategy(), ...),\n\n` +
      `# Стратегии BreakoutStrategyV2 / ExpandingTriangle / AscendingTriangle\n` +
      `# одновременно в disabled_strategy_names И в pipeline.\n` +
      `# Если disabled применяется через filter — ОК.\n` +
      `# Если нет — они торгуют несмотря на запрет.`,
    verdict: "противоречие",
    severity: "ВАЖНО",
    moneyImpact: "Если disabled_strategy_names не применяется как фильтр в pipeline.decide(), запрещённые стратегии продолжают торговать. Нет подтверждения, что фильтр активен в живом контуре.",
    minFix: "Проверить, что в `pipeline.decide()` или `_candidates_from_strategies()` есть `if strategy.name in config.disabled_strategy_names: continue`. Если нет — добавить. Затем убрать стратегии из pipeline init, если они в denylist.",
    section: "C",
  },
  {
    id: "C3",
    title: "candidate_prior_r: p_win = max(0.4, confidence) без ML даёт оптимистичный prior",
    location: "astra_bot/decision/meta_strategy.py:66–80",
    quote:
      `p_win = candidate.ml_probability if candidate.ml_probability is not None \\\n    else max(0.4, float(candidate.confidence))\np_win = min(0.99, max(0.01, p_win))\n\n` +
      `# confidence стратегий — произвольное число из scoring.py.\n` +
      `# Если confidence = 0.1 (низкая), prior clamp-ует до 0.4.\n` +
      `# Реальный win_rate = 28% (mean R ≈ −0.27 с RR 2.0).\n` +
      `# p_win 0.4 при среднем RR 2.0 → prior_r = 0.4×2 − 0.6×1 − costs ≈ +0.2R\n` +
      `# — оптимистично относительно исторических −0.27R.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "Prior-EV систематически завышен при отсутствии ML. Бот входит в сделки с более позитивным ожиданием, чем подтверждает история. EV-гейт пропускает больше сделок, чем должен.",
    minFix: "Снизить clamp до `max(0.35, confidence)` или лучше — вычислить исторический baseline winrate из strategy_stats ANY и использовать его как prior вместо константы 0.4.",
    section: "C",
  },
  {
    id: "C4",
    title: "HTF-shadow НЕ сохраняет zeus_trade_journal в Save state (zeus контур)",
    location: ".github/workflows/bot.yml:77 + scripts/run_paper_zeus.py",
    quote:
      `# В bot.yml Save state явно указан:\n` +
      `models/zeus_trade_journal.jsonl\n\n` +
      `# НО zeus paper-clock (run_paper_zeus.py) пишет в отдельные файлы:\n` +
      `ZEUS_STATE_PATH = \"models/zeus_paper_positions.json\"\n` +
      `ZEUS_TRADES_PATH = \"models/zeus_paper_trades.jsonl\"\n` +
      `ZEUS_STATS_PATH = \"models/zeus_strategy_stats.json\"\n` +
      `# Ни один из этих файлов НЕ перечислен в git add Save state.\n` +
      `# zeus_paper_positions.json, zeus_paper_trades.jsonl — не коммитируются.`,
    verdict: "баг",
    severity: "ВАЖНО",
    moneyImpact: "Если zeus-контур запускается из bot.yml — его state-файлы теряются при каждом рестарте. Позиции зевса «забываются», сделки задваиваются при следующем запуске.",
    minFix: "Добавить в Save state: `models/zeus_paper_positions.json`, `models/zeus_paper_trades.jsonl`, `models/zeus_strategy_stats.json`, `models/zeus_halt_alerts.json`.",
    section: "C",
  },

  // ────────── D. Данные и биржа ──────────────────────────────────────────
  {
    id: "D1",
    title: "BingX API ключи попадают в .env — нет проверки на утечку в логах",
    location: ".github/workflows/bot.yml:44–55 (Write .env step)",
    quote:
      `{\n  echo \"BINGX_API_KEY=$BINGX_API_KEY\"\n  echo \"BINGX_API_SECRET=$BINGX_API_SECRET\"\n  ...\n} > .env\n\n` +
      `# Файл .env создаётся chmod 600 — это ОК.\n` +
      `# НО: если run_bot.py или любой модуль логирует environ,\n` +
      `# ключи попадут в GitHub Actions logs (публичный репо!).\n` +
      `# Нет проверки, что logging.debug не выводит os.environ.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "Утечка API-ключей в публичный лог = возможный несанкционированный доступ к BingX-аккаунту. В paper-режиме реальных денег нет, но ключи могут быть общие с реальным аккаунтом.",
    minFix: "Добавить в setup_logging() маскировку ключей; grep по логам на паттерн `BINGX_API` в CI после запуска.",
    section: "D",
  },
  {
    id: "D2",
    title: "Незакрытый бар используется в structural_tighten через closed_bars",
    location: "astra_bot/decision/exit_plan.py:structural_tighten (closed_bars parameter)",
    quote:
      `def structural_tighten(\n    direction, entry, current_stop,\n    closed_bars: list[Any],  # caller должен передать ТОЛЬКО закрытые\n    ...\n) -> Decimal | None:\n    window = list(closed_bars)[-int(lookback):]\n    swing = min(float(b.low) for b in window)\n\n` +
      `# Функция не проверяет, что последний элемент closed_bars\n` +
      `# действительно закрытый. Caller — ExitPlanEngine в process_symbol.\n` +
      `# Если caller передаст все свечи (включая формирующуюся), swing\n` +
      `# будет считаться по текущему незакрытому low — lookahead.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "Структурный стоп может подтянуться слишком высоко/низко к незакрытому бару. В live-рынке это приведёт к преждевременным стопам или занижению stop_pct.",
    minFix: "В вызове structural_tighten передавать `closed_bars[:-1]` явно (уже делается для входных сигналов — применить ту же логику для выходов). Добавить ассерт `len(closed_bars) > 0 and not is_current_bar(closed_bars[-1])`.",
    section: "D",
  },

  // ────────── E. Учёт и метрики ──────────────────────────────────────────
  {
    id: "E1",
    title: "Zeus journal: 47 entry при 23 уникальных позициях — дубли подтверждены",
    location: "docs/research/DECISION_MEMO_2026-09-26.md (Zeus P1 section)",
    quote:
      `Zeus hygiene: raw entry 47 → unique ~23 (5-min collapse);\nstop_adjust=21; realized_pnl = sum(closed pnl).\n\n` +
      `# MEMO подтверждает: 47 записей entry = 23 реальных сетапа.\n` +
      `# sync_journal_from_broker() в run_paper_zeus.py определяет\n` +
      `# «новую позицию» по pid not in before — но before строится\n` +
      `# по снимку ДО шага, а тики бегут каждые 5 минут.\n` +
      `# При медленном журналировании pid может быть «новым» дважды.`,
    verdict: "баг",
    severity: "ВАЖНО",
    moneyImpact: "Удвоение entry в журнале искажает n, mean_R, PF для zeus-стратегий. DECISION_MEMO уже отмечает это, но фикс не реализован — данные для среза 06.10 будут содержать дубли.",
    minFix: "В sync_journal_from_broker проверять уникальность по `position_id` и не писать entry, если он уже есть в журнале. Добавить set known_position_ids аналогично known_trade_ids.",
    section: "E",
  },
  {
    id: "E2",
    title: "costs_r в снапшоте не учитывает фандинг (только fee + slippage)",
    location: "astra_bot/decision/trading_engine.py (notes 'costs_r' calculation)",
    quote:
      `\"costs_r\": 2.0 * (float(self.config.fee_pct) + float(self.config.slippage_pct))\n    / float(abs(entry_for_risk - cand.stop_loss) / entry_for_risk),\n\n` +
      `# Формула считает только fee + slippage (круг ≈ 0.3%).\n` +
      `# Фандинг не включён. При 4h-позиции, удерживаемой 48ч,\n` +
      `# фандинг добавляет 6 выплат × 0.01% × notional ≈ 0.06% notional.\n` +
      `# На стопе 1% это ещё +0.06R к реальным costs.`,
    verdict: "риск",
    severity: "КОСМЕТИКА",
    moneyImpact: "costs_r в снапшоте занижен на фандинг. Для 5m-стратегий (holding ~30 мин) незначимо; для 4h-стратегий (holding 48ч) упущено ~0.06R на сделку.",
    minFix: "В формулу costs_r добавить оценочный фандинг: `+ funding_rate * expected_hold_bars / funding_interval_bars`. Отметить в комментарии, что это приближение.",
    section: "E",
  },
  {
    id: "E3",
    title: "Kill-switch: правило «n≥5 И PF<1» реализовано только в README, в коде нет",
    location: "astra_bot/core/kill_switch.py (весь файл) + astra_bot/decision/strategy_stats.py",
    quote:
      `# kill_switch.py реализует только:\n` +
      `# 1. consecutive_loss_days >= 5 → HALT\n` +
      `# 2. weekly_loss_pct >= 3.0% → HALT\n\n` +
      `# Правило README «n≥5 и PF<1 → стратегия удаляется» —\n` +
      `# НЕ реализовано в kill_switch.py и НЕ реализовано\n` +
      `# явно в trading_engine.py (есть _check_hypothesis_degradation,\n` +
      `# но он работает с ACTIVE гипотезами, не с kill_switch n/PF).`,
    verdict: "противоречие",
    severity: "КРИТ",
    moneyImpact: "Главное защитное правило проекта «убить убыточную стратегию по n≥5, PF<1» не реализовано автоматически. Семь «мёртвых» стратегий (momentum PF=0.21, scalp PF=0.009) могут продолжать торговать.",
    minFix: "Добавить в _record_closed() проверку: для каждой закрытой стратегии, если `bucket.sample_size >= 5 and bucket.profit_factor < 1.0` → добавить её в `disabled_strategy_names` (или отдельный персистентный blacklist). Сохранять blacklist в state.",
    section: "E",
  },
  {
    id: "E4",
    title: "strategy_stats.py: probation ×0.25 описан в README, но не реализован как множитель размера",
    location: "astra_bot/decision/strategy_stats.py + trading_engine.py (sizing block)",
    quote:
      `# README: «стратегии с n<5 торгуют с probation-риском ×0.25»\n` +
      `# В shrunken_expectancy: при n=0 confidence=0.0\n` +
      `# В trading_engine sizing: если применяется — нет явного\n` +
      `# блока «if sample_size < 5: size *= 0.25».\n` +
      `# confidence=0.0 → EV = prior → проходит EV-гейт min_ev_r=0.05\n` +
      `# → размер НЕ уменьшается автоматически.`,
    verdict: "противоречие",
    severity: "КРИТ",
    moneyImpact: "Новые стратегии с n<5 торгуют на полном размере, а не на четверти. Если они убыточны (как исторически все новые), потери в 4 раза выше задекларированных.",
    minFix: "В блоке расчёта size в trading_engine добавить: `if sample_size < 5: risk_amount *= 0.25; binding_constraint = 'probation'`. Документировать: это hardcoded rule, не зависящий от confidence.",
    section: "E",
  },

  // ────────── F. Zeus контур ─────────────────────────────────────────────
  {
    id: "F1",
    title: "Zeus: путь от ENV до реального ордера потенциально открыт",
    location: "scripts/run_paper_zeus.py + astra_bot/decision/trading_engine.py",
    quote:
      `# run_paper_zeus.py создаёт TradingEngine с тем же BingXClient,\n` +
      `# что и main-бот. ENVIRONMENT=paper задаётся в .env.\n` +
      `# В bot.yml .env пишется: echo \"ENVIRONMENT=paper\" → .env\n` +
      `# Нет защиты «если zeus и ENVIRONMENT != paper → exit»\n` +
      `# в самом run_paper_zeus.py. При запуске с реальными ключами\n` +
      `# и ENVIRONMENT=live PaperBroker не используется — используется\n` +
      `# биржевой брокер.`,
    verdict: "риск",
    severity: "КРИТ",
    moneyImpact: "Теоретический путь к реальным ордерам через zeus-скрипт при смене ENVIRONMENT. В текущем CI защита есть (бот.yml всегда пишет paper), но локальный запуск без .env — риск.",
    minFix: "В run_paper_zeus.py добавить в начало: `assert os.environ.get('ENVIRONMENT', 'paper') == 'paper', 'Zeus runs only in paper mode'`. Явный fail-closed.",
    section: "F",
  },
  {
    id: "F2",
    title: "Zeus channel_boundary: min_stop_pct 0.8% — floor есть, но стоп считается от нижней границы канала, а не структуры",
    location: "astra_bot/strategies/zeus_channel_boundary.py:96–120 + DECISION_MEMO",
    quote:
      `stop = _enforce_min_stop(\n    \"long\", price, lower * (1 - c.stop_buffer_pct), c.min_stop_pct\n)\nrisk = price - stop\n\n` +
      `# stop_buffer_pct = 0.003 (0.3% под нижней границей).\n` +
      `# При канале шириной 1.5%, нижняя граница 1.5% ниже mid.\n` +
      `# Цена входа near_lo → расстояние = near_boundary_pct 1.5% + buffer 0.3% ≈ 1.8%.\n` +
      `# Но в узких каналах (width 1.2%) stop_pct ≈ 0.8–1.0%.\n` +
      `# costs_r = 0.3%/stop_pct ≈ 0.3R при stop_pct=1% — подтверждает MEMO.`,
    verdict: "риск",
    severity: "ВАЖНО",
    moneyImpact: "Узкий стоп канала (0.8–1.6%) даёт costs_r 0.19–0.38R — самая дорогая стратегия проекта по издержкам. При mean_R = −0.21 (ZEUS, 18 сделок) издержки составляют 80–180% от убытка.",
    minFix: "Минимальный стоп — противоположная граница канала (как указано в MEMO пре-регистрации). Изменить расчёт: `stop = opposite_boundary * (1 - buffer)`. Это изменит geometрию, требует новой paper-проверки.",
    section: "F",
  },

  // ────────── G. Процессы и документы ───────────────────────────────────
  {
    id: "G1",
    title: "DECISION_MEMO: «min_rr 0.7 был багом» — нет подтверждения исправления в коде",
    location: "docs/research/DECISION_MEMO_2026-09-26.md + trading_engine.py (cfg.min_rr)",
    quote:
      "| min_rr | 0.7 (баг) | 3.0 | 2.0 — согласовано с clamp_take_rr |\n\n" +
      "# MEMO говорит: исправлено до 2.0 (24.09).\n" +
      "# В trading_engine.py:\n" +
      "cfg.min_rr = 2.0  # Owner 24.09: align with clamp_take_rr 2.0-2.3\n\n" +
      "# ОК — подтверждено в коде. Но DecisionConfig.min_rr\n" +
      "# по умолчанию в config.py — нужно проверить default.",
    verdict: "ок",
    severity: "ОК",
    moneyImpact: "Исправлено. cfg.min_rr = 2.0 подтверждено в trading_engine.py строкой с комментарием.",
    minFix: "Нет действий. Рекомендуется добавить тест-золото: assert DecisionConfig().min_rr >= 2.0.",
    section: "G",
  },
  {
    id: "G2",
    title: "Тени (htf_shadow, pattern_exit_shadow) гарантированно не влияют на решения",
    location: "astra_bot/decision/pipeline.py (_htf_shadow_observe) + htf_shadow.py",
    quote:
      `def _htf_shadow_observe(self, ctx, candidates) -> None:\n    # ...\n    self.htf_shadow.record(...)  # только запись\n    # return без изменения candidates\n\n` +
      `# _htf_shadow_observe вызывается ПОСЛЕ _candidates_from_strategies\n` +
      `# и НЕ фильтрует candidates — только пишет в jsonl.\n` +
      `# Тени не меняют pipeline.decide() output — ОК по замыслу.`,
    verdict: "ок",
    severity: "ОК",
    moneyImpact: "Тени изолированы корректно. Нет пути влияния на живые решения.",
    minFix: "Нет действий. Проверка пройдена.",
    section: "G",
  },
  {
    id: "G3",
    title: "README обещает max_open_positions=3, max_same_direction=2 — в коде есть",
    location: "astra_bot/decision/trading_engine.py (TradingEngineConfig)",
    quote:
      `max_open_positions: int = 3\nmax_same_direction: int = 2\nmax_total_exposure_pct: Decimal = Decimal(\"0.30\")\n\n` +
      `# Все три лимита задекларированы в TradingEngineConfig.\n` +
      `# Применяются в risk_engine.check() перед открытием позиции.\n` +
      `# Соответствуют README.`,
    verdict: "ок",
    severity: "ОК",
    moneyImpact: "Соответствует канону. Нет действий.",
    minFix: "Нет действий. Проверка пройдена.",
    section: "G",
  },
  {
    id: "G4",
    title: "Бэктестер оптимистичнее paper: текущий бар как закрытый — задокументировано",
    location: "docs/BACKTEST_VS_PAPER_SEMANTICS.md (referenced in README)",
    quote:
      `# README явно указывает: «Бэктестер семантически оптимистичнее paper\n` +
      `# (текущий бар считается закрытым — B10, один тейк, нет funding):\n` +
      `# сравнивать можно только прогоны между собой.»\n\n` +
      `# Это задокументированное ограничение, не баг.`,
    verdict: "ок",
    severity: "ОК",
    moneyImpact: "Задокументировано. Бэктест-результаты не сравниваются с paper напрямую.",
    minFix: "Нет действий. Рекомендуется убедиться, что скрипты сравнения btekst/paper добавляют предупреждение.",
    section: "G",
  },
];

const sections: Section[] = [
  { id: "A", label: "A. Инфраструктура", icon: <GitBranch size={16} /> },
  { id: "B", label: "B. Исполнительный контур", icon: <Zap size={16} /> },
  { id: "C", label: "C. Сигналы и стратегии", icon: <TrendingDown size={16} /> },
  { id: "D", label: "D. Данные и биржа", icon: <Database size={16} /> },
  { id: "E", label: "E. Учёт и метрики", icon: <BarChart2 size={16} /> },
  { id: "F", label: "F. Контур Зевс", icon: <Shield size={16} /> },
  { id: "G", label: "G. Процессы и документы", icon: <FileText size={16} /> },
];

const top5: { rank: number; id: string; title: string; rImpact: string; why: string }[] = [
  {
    rank: 1,
    id: "E3 + E4",
    title: "Kill-switch n/PF не реализован + probation ×0.25 не применяется",
    rImpact: "≈ +8–15R/мес потерь относительно задекларированной защиты",
    why: "Главная защита проекта от убыточных стратегий существует только в README. При реальной торговле это означает полный размер позиций в убыточных стратегиях.",
  },
  {
    rank: 2,
    id: "A4",
    title: "kill_switch_state.json не коммитируется — HALT сбрасывается каждые 5 мин",
    rImpact: "≈ бесконечная торговля при должном HALT — весь риск недельного лимита",
    why: "Счётчик убыточных дней не переживает рестарт Actions. Бот физически не может накопить 5 убыточных дней — он забывает их при каждом новом процессе.",
  },
  {
    rank: 3,
    id: "B6",
    title: "MFE/MAE не обновляются побарно — TP-геометрия строится на искажённых данных",
    rImpact: "Решение о смене тейка с 2.0R → 0.70R принято на заниженных MFE",
    why: "Если MFE-медиана 0.28R — это артефакт измерения (захватывается только цена выхода), реальные пики цен могут быть выше. Планирование тейков на неверных данных меняет всю логику выходов.",
  },
  {
    rank: 4,
    id: "A5",
    title: "SymbolLossGuard не персистентен — per-symbol cooldown не работает",
    rImpact: "≈ 4h cooldown по символу никогда не действует между сессиями",
    why: "Бот входит в убыточный символ повторно на каждом следующем тике (5 мин), игнорируя cooldown. На истории 240 сделок это эквивалентно отсутствию этой защиты.",
  },
  {
    rank: 5,
    id: "E1",
    title: "Zeus journal: дубли entry (47 → 23) — статистика zeus искажена вдвое",
    rImpact: "n_zeus искусственно удвоен → PF, mean_R, решение о продвижении — неверны",
    why: "Оценка zeus-стратегий для среза 06.10 содержит задублированные записи. Любое решение «продвигать / закрыть» основано на неправильном n.",
  },
];

const goodThings = [
  {
    icon: "✅",
    title: "Атомарная запись state (tmp + os.replace)",
    desc: "state_store.py, broker.py, kill_switch.py — везде используется паттерн tmp-файл + os.replace. Частичного state на диске не бывает.",
  },
  {
    icon: "✅",
    title: "Закрытые бары для входных сигналов (A5)",
    desc: "pipeline.py: `_closed_entry_candles()` отрезает формирующийся бар. Lookahead на входных сигналах устранён корректно.",
  },
  {
    icon: "✅",
    title: "Двойная запись (ledger + trades)",
    desc: "paper_ledger.jsonl + paper_trades.jsonl: каждое событие (вход/выход/fee) пишется отдельно. E2E-replay сходится с брокером.",
  },
  {
    icon: "✅",
    title: "Concurrency-группа запрещает параллельные сессии",
    desc: "bot.yml: `concurrency: group: astra-bot, cancel-in-progress: false` — две cron-сессии не запускаются одновременно.",
  },
  {
    icon: "✅",
    title: "Инвариант «стоп только сжимается»",
    desc: "structural_tighten() проверяет candidate > cur (long) или candidate < cur (short) — стоп расшириться не может по построению.",
  },
  {
    icon: "✅",
    title: "Снапшот входа: 12 полей для аудируемости",
    desc: "signal_bar_close, costs_r, equity_before, prior_r и ещё 8 полей в каждой сделке — результаты полностью воспроизводимы.",
  },
  {
    icon: "✅",
    title: "Честный README — признаёт отрицательный mean_R",
    desc: "README явно говорит: mean_R = −0.27R на 240 сделках. Нет маркетинга, нет приукрашивания результатов.",
  },
  {
    icon: "✅",
    title: "Тени изолированы от решений",
    desc: "htf_shadow, pattern_exit_shadow, entry_gates — все три режима записи не имеют пути влияния на trading decision. Проверено в коде.",
  },
];

const openQuestions = [
  "Применяется ли `disabled_strategy_names` как фильтр в `pipeline.decide()`? Если нет — убитые стратегии всё ещё торгуют.",
  "Где именно в trading_engine.py применяется probation ×0.25 к размеру позиции? Найти строку кода или признать отсутствие реализации.",
  "Обновляются ли `pos.highest_price` / `pos.lowest_price` на каждом баре в `process_symbol`? Если нет — это источник проблемы B6.",
  "Zeus-контур: запускается ли `run_paper_zeus.py` из `bot.yml`? Если да — `zeus_paper_positions.json` теряется каждые 5 минут.",
  "Что происходит с `_daily_trade_count` при перезапуске сессии? Ограничение 6 сделок в день сбрасывается ли?",
  "Есть ли автоматический тест для `structural_tighten()`, подтверждающий, что функция не принимает незакрытый бар?",
];

// ─── Components ─────────────────────────────────────────────────────────────
function SeverityBadge({ severity }: { severity: Severity }) {
  const styles: Record<Severity, string> = {
    КРИТ: "bg-red-600 text-white",
    ВАЖНО: "bg-orange-500 text-white",
    КОСМЕТИКА: "bg-yellow-400 text-gray-900",
    ОК: "bg-green-600 text-white",
  };
  return (
    <span className={`px-2 py-0.5 rounded text-xs font-bold ${styles[severity]}`}>
      {severity}
    </span>
  );
}

function VerdictIcon({ verdict }: { verdict: Finding["verdict"] }) {
  if (verdict === "баг") return <XCircle size={16} className="text-red-500 shrink-0" />;
  if (verdict === "противоречие") return <AlertTriangle size={16} className="text-orange-500 shrink-0" />;
  if (verdict === "риск") return <AlertTriangle size={16} className="text-yellow-500 shrink-0" />;
  return <CheckCircle size={16} className="text-green-500 shrink-0" />;
}

function FindingCard({ finding }: { finding: Finding }) {
  const [open, setOpen] = useState(false);

  return (
    <div className={`border rounded-lg overflow-hidden mb-3 transition-all duration-200 ${
      finding.severity === "КРИТ"
        ? "border-red-600/60 bg-red-950/30"
        : finding.severity === "ВАЖНО"
        ? "border-orange-500/50 bg-orange-950/20"
        : finding.severity === "ОК"
        ? "border-green-600/40 bg-green-950/20"
        : "border-yellow-500/40 bg-yellow-950/20"
    }`}>
      <button
        className="w-full text-left px-4 py-3 flex items-center gap-3"
        onClick={() => setOpen((o) => !o)}
      >
        <VerdictIcon verdict={finding.verdict} />
        <span className="font-mono text-xs text-gray-400 shrink-0 w-8">{finding.id}</span>
        <span className="flex-1 font-medium text-sm text-gray-100">{finding.title}</span>
        <SeverityBadge severity={finding.severity} />
        {open ? (
          <ChevronDown size={14} className="text-gray-400 shrink-0 ml-2" />
        ) : (
          <ChevronRight size={14} className="text-gray-400 shrink-0 ml-2" />
        )}
      </button>

      {open && (
        <div className="px-4 pb-4 space-y-3 border-t border-white/10 pt-3">
          <div>
            <p className="text-xs text-gray-400 mb-1 flex items-center gap-1">
              <Search size={11} /> Местоположение
            </p>
            <code className="text-xs text-cyan-400 bg-gray-900/60 px-2 py-1 rounded block">
              {finding.location}
            </code>
          </div>
          <div>
            <p className="text-xs text-gray-400 mb-1 flex items-center gap-1">
              <BookOpen size={11} /> Цитата из кода
            </p>
            <pre className="text-xs bg-gray-900 border border-gray-700 rounded p-3 overflow-x-auto text-gray-300 leading-relaxed whitespace-pre-wrap">
              {finding.quote}
            </pre>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-gray-900/50 rounded p-3">
              <p className="text-xs text-orange-400 font-semibold mb-1">💰 Что это значит для денег</p>
              <p className="text-sm text-gray-200">{finding.moneyImpact}</p>
            </div>
            <div className="bg-gray-900/50 rounded p-3">
              <p className="text-xs text-blue-400 font-semibold mb-1">🔧 Минимальный фикс</p>
              <p className="text-sm text-gray-200">{finding.minFix}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">Вердикт:</span>
            <span className={`text-xs font-semibold px-2 py-0.5 rounded ${
              finding.verdict === "баг" ? "bg-red-900 text-red-300" :
              finding.verdict === "противоречие" ? "bg-orange-900 text-orange-300" :
              finding.verdict === "риск" ? "bg-yellow-900 text-yellow-300" :
              "bg-green-900 text-green-300"
            }`}>{finding.verdict}</span>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Main App ───────────────────────────────────────────────────────────────
export default function App() {
  const [activeSection, setActiveSection] = useState<string | "all" | "top5" | "good" | "questions" | "index">("top5");

  const critCount = findings.filter((f) => f.severity === "КРИТ").length;
  const impCount = findings.filter((f) => f.severity === "ВАЖНО").length;
  const cosCount = findings.filter((f) => f.severity === "КОСМЕТИКА").length;
  const okCount = findings.filter((f) => f.severity === "ОК").length;

  const displayed = activeSection === "all"
    ? findings
    : findings.filter((f) => f.section === activeSection);

  return (
    <div className="min-h-screen bg-gray-950 text-gray-100 font-sans">
      {/* Header */}
      <div className="bg-gradient-to-r from-gray-900 via-gray-900 to-gray-800 border-b border-gray-700 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex flex-col sm:flex-row sm:items-center gap-2">
          <div className="flex-1">
            <h1 className="text-lg font-bold text-white flex items-center gap-2">
              <Shield size={20} className="text-orange-400" />
              Независимый аудит astra_bot
            </h1>
            <p className="text-xs text-gray-400">Отчёт: 06.10.2026 · Внешний аудитор · Репо: Gamadril34rus/astra_bot</p>
          </div>
          <div className="flex gap-2 text-xs">
            <span className="bg-red-600/80 text-white px-2 py-1 rounded font-bold">{critCount} КРИТ</span>
            <span className="bg-orange-500/80 text-white px-2 py-1 rounded font-bold">{impCount} ВАЖНО</span>
            <span className="bg-yellow-400/80 text-gray-900 px-2 py-1 rounded font-bold">{cosCount} КОСМ</span>
            <span className="bg-green-600/80 text-white px-2 py-1 rounded font-bold">{okCount} ОК</span>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-6 flex gap-6">
        {/* Sidebar */}
        <aside className="w-52 shrink-0 hidden lg:block">
          <nav className="space-y-1 sticky top-20">
            <button
              className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-colors ${activeSection === "top5" ? "bg-orange-600 text-white" : "text-gray-400 hover:bg-gray-800"}`}
              onClick={() => setActiveSection("top5")}
            >
              <TrendingDown size={14} /> Топ-5 проблем
            </button>
            <button
              className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-colors ${activeSection === "good" ? "bg-green-700 text-white" : "text-gray-400 hover:bg-gray-800"}`}
              onClick={() => setActiveSection("good")}
            >
              <CheckCircle size={14} /> Что хорошо
            </button>
            <button
              className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-colors ${activeSection === "questions" ? "bg-blue-700 text-white" : "text-gray-400 hover:bg-gray-800"}`}
              onClick={() => setActiveSection("questions")}
            >
              <Info size={14} /> Открытые вопросы
            </button>
            <button
              className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-colors ${activeSection === "index" ? "bg-gray-600 text-white" : "text-gray-400 hover:bg-gray-800"}`}
              onClick={() => setActiveSection("index")}
            >
              <FileText size={14} /> Индекс находок
            </button>
            <div className="border-t border-gray-700 my-2" />
            <p className="text-xs text-gray-500 px-3 pb-1">По разделам:</p>
            {sections.map((s) => (
              <button
                key={s.id}
                className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-colors ${activeSection === s.id ? "bg-gray-700 text-white" : "text-gray-400 hover:bg-gray-800"}`}
                onClick={() => setActiveSection(s.id)}
              >
                {s.icon} {s.label}
              </button>
            ))}
            <button
              className={`w-full text-left px-3 py-2 rounded text-sm flex items-center gap-2 transition-colors ${activeSection === "all" ? "bg-gray-700 text-white" : "text-gray-400 hover:bg-gray-800"}`}
              onClick={() => setActiveSection("all")}
            >
              <Search size={14} /> Все находки
            </button>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0">
          {/* Mobile nav */}
          <div className="lg:hidden mb-4 flex gap-2 overflow-x-auto pb-1">
            {[
              { id: "top5", label: "Топ-5" },
              { id: "good", label: "Хорошо" },
              { id: "questions", label: "Вопросы" },
              { id: "index", label: "Индекс" },
              ...sections.map((s) => ({ id: s.id, label: s.id })),
              { id: "all", label: "Все" },
            ].map((item) => (
              <button
                key={item.id}
                className={`shrink-0 px-3 py-1.5 rounded text-xs font-medium transition-colors ${activeSection === item.id ? "bg-orange-600 text-white" : "bg-gray-800 text-gray-300"}`}
                onClick={() => setActiveSection(item.id)}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Top 5 */}
          {activeSection === "top5" && (
            <div>
              <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                <TrendingDown size={20} className="text-orange-400" />
                Топ-5 самых дорогих проблем
              </h2>
              <p className="text-sm text-gray-400 mb-6">По влиянию на PnL/риск, не по громкости бага. Грубая оценка на 240 исторических сделках.</p>
              <div className="space-y-4">
                {top5.map((item) => (
                  <div key={item.rank} className="border border-red-600/50 rounded-xl bg-red-950/20 p-5">
                    <div className="flex items-start gap-4">
                      <div className="text-4xl font-black text-red-600/70 leading-none w-10 shrink-0">{item.rank}</div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-mono text-xs bg-gray-800 px-2 py-0.5 rounded text-orange-400">{item.id}</span>
                          <h3 className="font-semibold text-white text-sm">{item.title}</h3>
                        </div>
                        <p className="text-orange-300 text-sm font-medium mb-2">📉 {item.rImpact}</p>
                        <p className="text-gray-300 text-sm">{item.why}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Good things */}
          {activeSection === "good" && (
            <div>
              <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                <CheckCircle size={20} className="text-green-400" />
                Что работает хорошо
              </h2>
              <p className="text-sm text-gray-400 mb-6">Минимум 5 честных пунктов. Аудит — не охота на ведьм.</p>
              <div className="grid md:grid-cols-2 gap-4">
                {goodThings.map((item, i) => (
                  <div key={i} className="border border-green-600/40 bg-green-950/20 rounded-xl p-4">
                    <div className="text-2xl mb-2">{item.icon}</div>
                    <h3 className="font-semibold text-green-300 text-sm mb-1">{item.title}</h3>
                    <p className="text-gray-300 text-sm">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Open questions */}
          {activeSection === "questions" && (
            <div>
              <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                <Info size={20} className="text-blue-400" />
                Что проверить срезом
              </h2>
              <p className="text-sm text-gray-400 mb-6">Вопросы, на которые нет ответа в данных. Повестка следующего среза.</p>
              <div className="space-y-3">
                {openQuestions.map((q, i) => (
                  <div key={i} className="border border-blue-500/30 bg-blue-950/20 rounded-lg p-4 flex gap-3">
                    <span className="text-blue-400 font-bold text-sm shrink-0">Q{i + 1}</span>
                    <p className="text-gray-200 text-sm">{q}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Index */}
          {activeSection === "index" && (
            <div>
              <h2 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
                <FileText size={20} className="text-gray-300" />
                Индекс находок
              </h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm border-collapse">
                  <thead>
                    <tr className="border-b border-gray-700 text-gray-400 text-xs">
                      <th className="text-left py-2 pr-4 font-medium">ID</th>
                      <th className="text-left py-2 pr-4 font-medium">Файл</th>
                      <th className="text-left py-2 pr-4 font-medium">Severity</th>
                      <th className="text-left py-2 font-medium">Суть</th>
                    </tr>
                  </thead>
                  <tbody>
                    {findings.map((f) => (
                      <tr
                        key={f.id}
                        className="border-b border-gray-800 hover:bg-gray-800/50 cursor-pointer"
                        onClick={() => setActiveSection(f.section)}
                      >
                        <td className="py-2 pr-4 font-mono text-orange-400 text-xs">{f.id}</td>
                        <td className="py-2 pr-4 text-cyan-400 text-xs max-w-xs truncate">{f.location.split(" ")[0]}</td>
                        <td className="py-2 pr-4"><SeverityBadge severity={f.severity} /></td>
                        <td className="py-2 text-gray-300 text-xs">{f.title}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Section findings */}
          {(sections.some((s) => s.id === activeSection) || activeSection === "all") && (
            <div>
              <h2 className="text-xl font-bold text-white mb-1 flex items-center gap-2">
                {activeSection === "all"
                  ? <><Search size={20} className="text-gray-400" /> Все находки</>
                  : <>{sections.find((s) => s.id === activeSection)?.icon} {sections.find((s) => s.id === activeSection)?.label}</>
                }
              </h2>
              <p className="text-xs text-gray-500 mb-4">Нажмите на карточку, чтобы раскрыть детали, цитату из кода и минимальный фикс.</p>
              {displayed.length === 0 ? (
                <p className="text-gray-500 text-sm">Находок в этом разделе нет.</p>
              ) : (
                displayed.map((f) => <FindingCard key={f.id} finding={f} />)
              )}
            </div>
          )}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-gray-800 mt-12 py-6 text-center text-xs text-gray-600">
        <p>Независимый аудит · astra_bot · Gamadril34rus/astra_bot · {new Date("2026-10-06").toLocaleDateString("ru-RU")}</p>
        <p className="mt-1">Все цитаты прочитаны из исходников репозитория напрямую. Отчёт: reports/audit_external_2026-10-06.md</p>
      </footer>
    </div>
  );
}
